## Monitoring Consumer Lag

## Spin Up Local Kafka Container
```
$ make start-kafka
```

## Verify that Kafka is Up
```
$ make check-kafka
```

## Stop Local Kafka Container
```
$ make stop-kafka
```
